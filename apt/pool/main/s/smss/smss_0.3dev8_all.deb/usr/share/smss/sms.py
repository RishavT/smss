import urllib, urllib2,urlparse,re,cookielib,getpass
#self.sendmessage("9967581588","hi my name is darius")
class SMSS:
  
  def login(self,phone,passwd):
  
    
  
    login_encode=urllib.urlencode({'MobileNoLogin':phone, 'LoginPassword':passwd})
    cookieprocessor=urllib2.HTTPCookieProcessor() #new cookie processor
    self.o = urllib2.build_opener(cookieprocessor) # a new urlopener
    f = self.tryopen(self.o,'http://fullonsms.com/CheckLogin.php',login_encode)
    self.tempo = f.read()
    print self.tempo
    if self.tempo.find('http://fullonsms.com/trai.php?Login=1') != -1:
      #print 'yeahhh'
      return 1
    else:
      #print 'sorry'
      return 0
  
  def tryopen(self,opener,url,data=None):
  
    while True:
      try:
        f = opener.open(url,data)
        return f
      except urllib2.URLError:
        print "Caught an Exception URLError. Retrying..."
        return 2
  
  def send(self,to_number,message):
    
  
    
  ### send the message
  
    info =  urllib.urlencode({
                  "CancelScript":"/home.php",
                  "MobileNos":to_number,
                  "Message":message,
                  "SelGroup":"",
                  "Gender":"0",
                  "FriendName":"Your Friend Name",
                  "ETemplatesId":"",
                  "TabValue":"contacts"
                  })
      
    f = self.tryopen(self.o,'http://fullonsms.com/home.php',info)
    data_returned=f.readlines()[-1]
  
    if data_returned.find('http://fullonsms.com/MsgSent.php')!=-1:
      print 'sent'
      return True
    else:
      print 'failed'
      return False
